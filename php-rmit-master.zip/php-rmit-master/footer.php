  <footer>
    <div class="footer-wrapper">
      <ul>
        <li><i class="fas fa-hospital "></i> Medical Clinic</li>
        <li><i class="fa fa-location-arrow" aria-hidden="true"></i> 36 Pinelands Dr, Beerwah QLD 4519, Australia</li>
        <li><i class="fa fa-phone" aria-hidden="true"></i> +61754399729</li>
      </ul>
      <ul>
        <li> <i class="fa fa-user" aria-hidden="true"></i> Minh Duc Nguyen</li>
        <li><i class="fa fa-bookmark" aria-hidden="true"></i> student id: s3766338</li>
      </ul>
    </div>
  </footer>